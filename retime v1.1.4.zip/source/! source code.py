###########      IMPORTING      ##########

import tkinter as tk #import tkinter for gui
import os #contains quit and getting directory
from decimal import Decimal as d #decimal is much more accurate than floats

###########      IMPORTING      ##########



###########      BULK OF CODE      ##########
# everything in this section is executed every time something changes.

def my_tracer(a, b, c): # traced variables send 3 arguments to this
    try:
        fr=d(fv.get())
    except:
        fr=1000 #by default, no rounding happens. not recommended
    
    try:
        mod=cTime(mv.get())
        #print('c',mod)
    except:     #the modifier, added to the resulting time
        try:
            mod=frac(mv.get())
            #print('f',mod)
        except:
            try:
                mod=numtime(mv.get()) # yes
                #print('n',mod)
            except:
                mod=d(0)
                #print('0',mod)

    start="x"
    end="x"
    form=0 # keeps track of format of result

    stext = sv.get().split(',') #start point

    for i in range (len(stext)):
        if stext[i][4:7]=='cmt':
            start=d(stext[i].split('"')[-2]) #crops out the useless stuff
            start = d(start - start%(d(1)/fr)) #rounds down the time to the start of a frame

    if start == "x":
        try:
            start=cTime(sv.get())
            form-=1
        except:
            try:
                start=numtime(sv.get(),True)
                form+=1
            except:
                start="x"

    etext = ev.get().split(',') #end point
    for i in range (len(etext)):
        if etext[i][4:7]=='cmt':
            end=d(etext[i].split('"')[-2])
            end = d(end - end%(d(1)/fr))

    if end == "x":
        try:
            end=cTime(ev.get())
            form-=1
        except:
            try:
                end=numtime(ev.get(),True)
                form+=1
            except:
                end="x"


    try:        # if youtube debug info is entered correctly, displays time as h m s ms
        if end-start+mod < 0:
            negative=True   # if start > end, a negative is put in front of the absolute value of
                            #the result
        else:
            negative=False # !!! y+y>m y+m>m y+:>: m+m>m :+:>: m+:>m
        if form > -1:
            new_text = negative*"- "+realtime(abs(end-start+mod))
        else:
            new_text = negative*"-"+uTime(abs(end-start+mod))
    except:
        new_text = ""
        
    tv.set(new_text)
    #tv.set("- 999h 59m 59s 999ms")     #debug line to get longest conceivable input
###########      BULK OF CODE      ##########


###########      MISC. FUNCTIONS      ##########
def close():    # normally, pressing the close button on tkinter window doesn't terminate script
    os._exit(0) # <- ends script so it doesn't keep running


def cTime(a): #converts x:xx:xx.xxx to xxxxxx.xxx
    x=d(0)
    for i in range(len(a.split(":"))):
        x+=d(60)**d(i)*d(a.split(":")[-(i+1)])
    return d(x)

def uTime(a): #inverse of cTime
    a = round(a,3)              #166ms or 167ms???
    t1, t0 = divmod(a, 1)
    t2, t1 = divmod(t1, 60)
    t3, t2 = divmod(t2, 60)
    t0= round(t0*1000)
    if t0==0:
        t4, t3 = divmod(t3,  60)
    else:
        t4=0

    if t4!=0:       #formatting :(
        return("%d:%02d:%02d:%02d" % (t4, t3, t2, t1))
    elif t3!=0 and t0!=0:   # despite similarities, realtime and uTime can't be merged into
                            #the same function because :::. and h/m/s/ms are read differently
        return("%d:%02d:%02d.%03d" % (t3, t2, t1, t0))
    elif t3!=0 and t0==0:
        return("%d:%02d:%02d" % (t3, t2, t1))
    elif t2!=0 and t0!=0:
        return("%d:%02d.%03d" % (t2, t1,t0))
    elif t2!=0 and t0==0:
        return(("%d:%02d" % (t2, t1)))
    elif t0!=0:
        return("%d.%03d" % (t1,t0))
    else:
        return(str(int(t1)))
    

def realtime(time): # turn XXXXXX.xxx into XXXh XXm XXs xxxms
    #print(time)
    time=round(time,3)
    ms=(1000*time)%1000
    time-=time%1
    s=time%60
    time=(time-s)/60      #finding number of hours, minutes, etc
    m=time%60
    time=(time-m)/60
    h=time

    #print(h)
    #print(m)
    #print(s)
    #print(ms)

    ms="{:03d}".format(int(ms)) #formatting
    if h!=0:
        h=int(h)
        m="{:02d}".format(int(m))
        s="{:02d}".format(int(s))
        return(str(h)+'h '+str(m)+'m '+str(s)+'s '+str(ms)+'ms')
    elif m!=0:
        m=int(m)
        s="{:02d}".format(int(s))
        return(str(m)+'m '+str(s)+'s '+str(ms)+'ms')
    else:
        s=int(s)
        return(str(s)+'s '+str(ms)+'ms')

def numtime(s,x=False):
    if x and s == "":
        return "x"
    s.replace("ms","n")
    a=s.find("n")
    b=s.find("s")
    c=s.find("m")
    e=s.find("h")

    if s.find("-")>-1:
        n=-1
    else:
        n=1

    ms,se,mn,hr=0,0,0,0
    
    if a>-1:
        ms=s[max(a-2,0):a]
    if b>-1:
        se=s[max(b-2,0):b]
    if c>-1:
        mn=s[max(c-2,0):c]
    if e>-1:
        hr=s[0:e]

    return d(n)*(d(ms)/d(1000)+d(se)+d(60)*d(mn)+d(3600)*d(hr)) 

def frac(x):
    a,b = x.split('/')
    return d(a)/d(b)

#print(realtime(d(5.999999999999972)))
#print(realtime(d(6.000000000000072)))     # float precision tests
#print(uTime(d(5.999999999999972)))        # i hate floats :(
#print(uTime(d(6.000000000000000072)))
#print(uTime(d(0.99)))
#print(frac("12/23"))
    
###########      MISC. FUNCTIONS      ##########



###########      GUI      ##########
    
while True:
    root = tk.Tk()
    root.title("SP's Retiming Tool")
    root.iconbitmap(os.getcwd()+"\source\icon.ico")
    root.protocol("WM_DELETE_WINDOW", close) # procedure done upon clicking X

    tk.Label(root,text="Video FPS",font=("Hobo Std", 16)).grid(row=0,column=0)
    tk.Label(root,text="Modifier",font=("Hobo Std", 16)).grid(row=0,column=1)

    fv= tk.StringVar()
    fv.trace('w', my_tracer)
    f=tk.Entry(root,width=5,font=("Hobo Std", 30),justify='center',textvariable=fv) #framerate
    f.grid(row=1,column=0,columnspan=1)
    # ^ All input code will look something like this, allowing my_tracer() to
    #update every time any updates are made
    

    mv = tk.StringVar()
    mv.trace('w', my_tracer)
    m=tk.Entry(root,width=19,font=("Hobo Std", 18),justify='center',textvariable=mv) #framerate
    m.grid(row=1,column=1,columnspan=1)
    # Modifier is added to the result, allowing for quick changes to it.
    #of course, this can be negative


    tk.Label(root,text="Start frame",
             font=("Hobo Std", 16)).grid(row=2,columnspan=3)
    sv = tk.StringVar() # using StringVar means the result can
                        #dynamically change as entry values change
    sv.trace('w', my_tracer) # run my_tracer if value was changed (w = write)
    s=tk.Entry(root,width=26,font=("Hobo Std", 20),textvariable=sv) #start debug info
    s.grid(row=3,column=0,columnspan=2)

    
    tk.Label(root,text="End frame",
             font=("Hobo Std", 16)).grid(row=4,columnspan=3)
    ev = tk.StringVar() # or StringVar(top) 
    ev.trace('w', my_tracer) # run my_tracer if value was changed (w = write)
    e=tk.Entry(root,width=26,font=("Hobo Std", 20),textvariable=ev) #end debug info
    e.grid(row=5,column=0,columnspan=2)

    tv = tk.StringVar() # or StringVar(top) 
    t = tk.Label(root, textvariable=tv,font=("Hobo Std", 30),background="white",width=18)
    t.grid(row=7,columnspan=2,pady=(10,5),padx=10)


    def clear(): #restores all inputs to default values and clears the output
        f.delete(0, tk.END)
        m.delete(0, tk.END)
        s.delete(0, tk.END)
        e.delete(0, tk.END)
        tv.set("")
        
    cb=tk.Button(root,text="Clear",font=("Hobo Std", 30),width=14,command=clear)
    cb.grid(row=8,columnspan=2,pady=5)

    root.mainloop() #executes the code

###########      GUI      ##########

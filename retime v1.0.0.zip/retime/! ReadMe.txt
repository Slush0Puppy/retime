Hello, user!
This is v1.0.0 of Slush Puppy's retime software, designed for precisely retiming speedruns down to the millisecond. Currently, this only works for videos hosted on YouTube.


To use this, first of all find the framerate of the YouTube video you want to retime. Right click the video and click "Stats for nerds", and at the start of the 3rd line (titled "Current / Optimal Res") there will be a resolution followed by @xx, where xx is the framerate of the video. Enter this into the framerate box.

Next, find the first frame of the run. By using the , and . keys, you can advance one frame at a time to find the exact point. When you have found it, right click and select "Copy debug info", then paste (Ctrl+V) it into the "Start frame" box.
Do the same for the end frame.

Next, click GO and the exact time will be displayed.


The "Modifier" box will add a certain amount of time to the result. This is especially useful for games with unusual timing methods like Super Mario 64, where the timer is always at exactly 1.33 seconds on the first frame the logo appears. Moderators could set the Start frame to this point and set the Modifier to 1.33.

The "Fair frame" (off by default) will add one frame to the run, thus changing the timing method from start-end timing to a timing method that measures the total number of frames elapsed. This is arguably a much more fair method of timing because someone with a very low framerate may appear to have a faster time than they actually have under some circumstances. However, this should only be used if the entire board is following the same rule, as adding a frame to some users and not others will give an even more unfair disadvantage, especially in tighter categories where one frame can make a huge difference.


CREDITS:
src/SlushPuppy: Developing the software
src/Oxknifer: Beta testing